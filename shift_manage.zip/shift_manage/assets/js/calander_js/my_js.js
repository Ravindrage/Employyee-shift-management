// Validating Empty Field
function check_empty(value) {
if (document.getElementById('event').value == "" || document.getElementById('description').value == "" ) {
alert("Fill All Fields !");
} else {
$(function ()
{

eventdata = document.getElementById('event').value ;
eventdesc = document.getElementById('description').value ;
dataid = document.getElementById('dataid').value ;

action =  value ;
//var status = document.getElementById('status').value ;
document.getElementById('abc').style.display = "none";

$.ajax({ url:action,
         data:"eventdata="+eventdata+"&eventdesc="+eventdesc+"&action="+action+"&dataid="+dataid+"&status="+status,
         dataType:'json',
         type:"post",
        success: function(result){
              location.reload();
            if(result.toString()==="delete")
            {
              document.getElementById(dataid).remove();
              div_hide1();
            }else{
            document.getElementById(dataid).innerHTML = result;
           }
       div_hide1();
     window.location.reload();
    }

  });
  window.location.reload(true);
//  location.reload(true);


});
}
}



function shift_update()
 {
  //alert( document.getElementById('shiftchange').style.display);
  document.getElementById('shiftchange').style.display = 'block' ;
 }

 function request_shift(empid)
 {
   document.getElementById('shiftchange').style.display = 'none' ;
   var shiftid = document.getElementById('up_shift').value ;
   alert("Request for Updating Shift Sent to Admin ");
   //document.getElementById('').value ;

   $.ajax({ url: "updateshift",
            data: "empid="+empid+"&shiftid="+shiftid,
            dataType: 'json',
            type: "post",
            success: function(result){

            }
          })
}

function check_save(value) {
if (document.getElementById('event1').value == "" || document.getElementById('description1').value == "" ) {
alert("Fill All Fields !");
} else {


$(function ()
{
  //-------------------------------------------------------------------------------------------
  // 2) Send a http request with AJAX http://api.jquery.com/jQuery.ajax/
  //-------------------------------------------------------------------------------------------

eventdata = document.getElementById('event1').value ;
eventdesc = document.getElementById('description1').value ;
section = document.getElementById('sectionfield').value ;
date = document.getElementById('date1').value ;
relX = document.getElementById('left').value ;
relY = document.getElementById('top').value ;
action =  value ;

document.getElementById('abc1').style.display = "none";

$.ajax({ url: action,
        data: "eventdata="+eventdata+"&eventdesc="+eventdesc+"&action="+action+"&section="+section+"&date="+date,
        dataType: 'json',
        type: "post",

        success: function(result){
          document.getElementById('abc1').style.display = "none";
           window.location.reload();
           div_hide1();
        result_item = result.split("$");
        //alert(result_item);

       document.getElementById(relX).innerHTML = '<div id='+result_item[0]+' class="time-sch-item item-status-none ui-draggable ui-resizable" style="top:'+relY+'; width:100%;">'+result_item[1]+'</div>' ;
       //alert(document.getElementById(relX).innerHTML);
       document.getElementById('abc1').style.display = "none";
    }});

    window.location.reload(true);
});

}
}

//Function To Display Popup
function div_show() {
document.getElementById('abc').style.display = "block";
}
//Function to Hide Popup
function div_hide(){
document.getElementById('abc').style.display = "none";
}


function div_show1(id) {


if(document.getElementById('abc').style.display != "block")
{

document.getElementById('sectionfield').value = id ;
document.getElementById('event1').value = "" ;
document.getElementById('description1').value = "" ;
document.getElementById('date1').value = "" ;
document.getElementById('abc1').style.display = "block";
//var start = document.getElementById('starttime').value ;
//  var end = document.getElementById('endtime').value ;


$("#container").click(function(e){
   var wrapper = $(this).parent();
   var parentOffset = wrapper.offset();
   var relX = e.pageX - parentOffset.left + wrapper.scrollLeft();
   var relY = e.pageY - parentOffset.top + wrapper.scrollTop();

   $(this).append($('<div/>').addClass('placeddiv').attr("id",relX).css({
       left: relX-280,
       top: relY
   }));

   document.getElementById('left').value = relX ;
   document.getElementById('top').value = relY ;
});
}
}
//Function to Hide Popup
function div_hide1(){
document.getElementById('abc1').style.display = "none";
}

function sectionpopuphide(){
document.getElementById('sectionpopup').style.display = "none";
}

function sectionpopuphide2(){
document.getElementById('sectionpopup1').style.display = "none";
}
