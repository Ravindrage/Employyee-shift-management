<?php

class shift_manage extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //print_r($this->session->userdata ); exit;
    if( !$this->session->userdata('isLoggedIn') ) {
        redirect('/login/show_login');
    }
  }

  function shift() {
  // echo "shift"; exit;
    $this->load->model('shift_m');

    $user_id = $this->session->userdata('id');
    $is_admin = $this->session->userdata('isAdmin');
    $team_id = $this->session->userdata('teamId');

    $posts = $this->shift_m->get_calender_user( $user_id );
    $time = $this->shift_m->get_time_user( $user_id );
    $alltime = $this->get_all_time( $time );
    $variable = '';

    foreach($posts as $rowcategory)
    {
    $increment = $rowcategory['id'] ;
    $datetime = $rowcategory['datetime'] ;
    $event = $rowcategory['event'] ;
    $description = $rowcategory['description'] ;
    $section = $rowcategory['section'] ;

    $newDate = date("m-d-Y", strtotime($datetime));
    //$originalDate = $datetime ;

    $variable .= "{ id: ".$increment.", name: '<div>".$event."</div><div>".$description."</div>',
                    start: moment('".$newDate."','MM-DD-YYYY'),
                    end: moment('".$newDate."','MM-DD-YYYY'), sectionID: '".$section."',classes: 'item-status-none'
                  },";
    }

    $allshift = $this->shift_m->allshift();
    $getshift = $this->shift_m->getshift($user_id);

    ///$this->session->set_userdata(array('') );

    //$data['allshift'] = $allshift ;
    $mainvariable = array('main' => $variable ,'alltime' =>$alltime,'is_admin' => $is_admin,'allshift' =>$allshift,'userid' => $user_id ,'currentshift'=>$getshift );
    //print_r($mainvariable);
    $this->load->view('shift_manage',$mainvariable);

  }

  function get_all_time( $time )
  {
      $sectionvariable = '';
      $totalsection=0;

      foreach($time as $rowcategory)
      {
      $id = $rowcategory['id'] ;
      $section = $rowcategory['section'] ;
      $sectionvariable .= "{     id: ".$id.",    name: '".$section."' },";
      $totalsection++ ;
      }

      if( !empty($sectionvariable)) {
       return $sectionvariable;
      }
      return false ;
  }

function save() {
    //$this->input->post();
    $this->load->model('shift_m');
    print_r($this->input->post());
    //$event = trim($_REQUEST['eventdata']);
    //$description = trim($_REQUEST['eventdesc']);
    $description ;
    $last_id  = $this->shift_m->saveEvent($this->input->post());
    //redirect($this->uri->uri_string());
    return ;

}

function edit() {
  $this->load->model('shift_m');
  $last_id  = $this->shift_m->editEvent($this->input->post());
  //redirect($this->uri->uri_string());
  return $last_id;
 }

function assign(){

  $this->load->model('shift_m');
  $userdata = $this->shift_m->showemploye_shift();
  $requestshift = $this->shift_m->requestemploye_shift();
  //print_r($userdata);
  $allshift = $this->shift_m->allshift();

  $user_id = $this->session->userdata('id');
  $is_admin = $this->session->userdata('isAdmin');
  $team_id = $this->session->userdata('teamId');
  //$this->load->model('messages_model');
  //$messages = $this->messages_model->get_all_entries();

  $getshift = $this->shift_m->getshift($user_id);

  $data['userdata'] = $userdata;
  $data['is_admin'] = $is_admin;
  $data['user_id'] = $user_id;
  $data['allshift'] = $allshift ;
  $data['requestshift'] = $requestshift ;
  $data['currentshift'] = $getshift;

  $this->load->view('header',$data) ;
  $this->load->view('employeeshift',$data);
}

function editshift()
    {

      $this->input->post();
      $employe_id = trim($_REQUEST['id']);
      $data['shift_id'] = trim($_REQUEST['shiftid']);
      $data['up_shift'] = 0 ;
      $this->db->update('user', $data, array('id' => $employe_id));
      $this->db->last_query();
      echo "success";
      //redirect($this->uri->uri_string());

    }


function updateshift()
    {

      $this->input->post();
      $employe_id = trim($_REQUEST['empid']);
      //$data['shift_id'] = trim($_REQUEST['shiftid']);
      $data['up_shift'] = trim($_REQUEST['shiftid']) ;
      $this->db->update('user', $data, array('id' => $employe_id));
      echo  $this->db->last_query();
      echo "success";

    }






}


  ?>
