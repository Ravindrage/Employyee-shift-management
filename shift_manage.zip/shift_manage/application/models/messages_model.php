<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Messages_model extends CI_Model {

    var $name   = '';
    var $starttime = '';
    var $endtime = '';
    var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function get_all_entries()
    {
        $query = $this->db->get('shift');
        return $query->result();
    }


    function getshift($user_id)
    {

      $this->db->select('shift.name');
      $this->db->from('user');
      $this->db->join('shift','user.shift_id = shift.id', 'left');
      $this->db->where( array('user.id'=>$user_id) );
      $query = $this->db->get();
      $this->db->last_query();
      return $query->result();
    }

    function insert_entry($data)
    {
        echo $this->name = $data['name']; // please read the below note
        echo $this->starttime = $data['starttime'];
        echo $this->endtime = $data['endtime'];
        $this->date = time();
        $this->db->insert('shift', $this);
        $this->db->last_query();
        redirect($this->uri->uri_string());
        //exit;
    }

    function update_entry($data)
    {
        echo $this->name   = $data['name']; // please read the below note
        echo $this->starttime = $data['starttime'];
        echo $this->endtime = $data['endtime'];
        $this->date    = time();

        $this->db->update('shift', $this, array('id' => $data['id']));
        $this->db->last_query();
        redirect($this->uri->uri_string());
        //exit;
    }

    function delete_entry($id)
    {
        $this->db->delete('shift', array('id' => $id));
        $this->db->last_query();
        //redirect($this->uri->uri_string());
          //exit;
    }

    function get_entry($id){
        $this->db->where('id', $id);
        $query = $this->db->get('shift', 1);
        return $query->result();
    }

}
