<?php

class shift_m extends CI_Model {
    var $details;

   function get_calender_user( $user_id )
   {
    // echo $user_id;
     $this->db->from('calendar');
     $this->db->where( array('userId'=>$user_id) );
     $this->db->order_by('datetime','desc');
     $posts = $this->db->get()->result_array();
     if( is_array($posts) && count($posts) > 0 ) {
       return $posts;
     }
     return false;
   }


   function getshift($user_id)
   {

     $this->db->select('shift.name');
     $this->db->from('user');
     $this->db->join('shift','user.shift_id = shift.id', 'left');
     $this->db->where( array('user.id'=>$user_id) );

     $query = $this->db->get();
     $this->db->last_query();
     return $query->result();


   }

   function get_time_user ( $user_id )
   {

     $this->db->from('section');
     $this->db->order_by('id');
     $time = $this->db->get()->result_array();

     if( is_array($time) && count($time) > 0 ) {
       return $time;
     }
    return false;
    }


  function editEvent($array)
   {

     $user_id = $this->session->userdata('id');
     $data['event'] =$array['eventdata'] ;
     $data['description'] =$array['eventdesc'] ;
     $id =$array['dataid'] ;

    // $data=array('last_login'=>current_login,'current_login'=>date('Y-m-d H:i:s'));
     $this->db->where('id',$id);
     $this->db->update('calendar',$data);
     return $id;


   }

  function saveEvent($array)
  {
    $user_id = $this->session->userdata('id');
    $data['event'] =$array['eventdata'] ;
    $data['description'] =$array['eventdesc'] ;
    //$data['datetime'] =$array['date'] ;
    $data['datetime'] = date("Y-m-d",strtotime($array['date']));
    $data['section'] =$array['section'] ;
    $data['userId'] = $user_id ;

    if ( $this->db->insert('calendar',$data) ) {

      $lastid = $this->db->insert_id();
      $this->db->from('calendar');
      $this->db->where(array('id'=>$lastid));
      $posts = $this->db->get()->result_array();

      if( is_array($posts) && count($posts) > 0 ) { return $posts;  }

    } else {
      return false;
    }

  }


function showemploye_shift()
   {

  $this->db->select('user.*,shift.name');
  $this->db->from('user');
  $this->db->join('shift','user.shift_id = shift.id', 'left');

  $query = $this->db->get();
  $this->db->last_query();
  return $query->result();

   }


   function requestemploye_shift()
      {

     $this->db->select('user.*,shift.name');
     $this->db->from('user');
     $this->db->join('shift','user.up_shift = shift.id', 'left');

     $query = $this->db->get();
     $this->db->last_query();
     return $query->result();

      }


function allshift()
   {
     $this->db->from('shift');
     $allshift = $this->db->get()->result_array();

     if( is_array($allshift) && count($allshift) > 0 ) {
       return $allshift;
     }

    return false;

   }





  }



 ?>
