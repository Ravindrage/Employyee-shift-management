
		<div id="body">
			
   <div class="shift">
		<h4><?php if(isset($summary) && $summary != "") echo $summary; ?></h4>

		<form method="POST" action="<?php echo base_url() ?>index.php/edit/input" style="text-align:center;">
			<input type="hidden" name="id" value="<?php echo $entry->id; ?>"/>
			Name: <input type="text" name="name" value="<?php echo $entry->name; ?>"/><br/>
			Start Time: <input type="text" name="starttime" value="<?php echo $entry->starttime; ?>"/> <br/>
			End Time: <input type="text" name="endtime" value="<?php echo $entry->endtime; ?>"/><br/>
			<input type="submit" value="Update" />
		</form>
	</div>
</div>
