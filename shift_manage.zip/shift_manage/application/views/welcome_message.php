

		<h4><?php if(isset($summary) && $summary != "") echo $summary; ?></h4>
		<div id="shift" class="shift"> <a href='<?php echo base_url() ?>/index.php/create/index'>Create Shift</a>
		<table class='table'>
			<tr>

				<td>Date</td>
				<td>Name</td>
				<td>Start Time</td>
				<td>End Time</td>
				<td>Action</td>
			</tr>
			<?php foreach($messages as $m){ ?>
				<tr>

					<td> <?php echo date("M-d-Y g:i", strtotime($m->date)); ?> </td>
					<td> <?php echo $m->name; ?> </td>
					<td> <?php echo $m->starttime; ?> </td>
					<td> <?php echo $m->endtime; ?> </td>
					<td>
						 <a href='<?php echo base_url() ?>index.php/edit/index/<?php echo $m->id; ?>'>Edit</a>
						 <a href='<?php echo base_url() ?>index.php/edit/delete/<?php echo $m->id; ?>'>Delete</a>
				    </td>
				</tr>
			<?php } ?>
		</table>
	</div>
