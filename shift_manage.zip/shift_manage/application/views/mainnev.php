<div id="body">
<div class="navbar">
	<div class="navbar-inner">
		<div class="container-fluid">
			<a class="brand" href="#" name="top">Employee Shift</a>
				<ul class="nav">
					<li><a href="#"><i class="icon-home"></i> Home</a></li>
					<li><a href="<?php echo base_url() ?>index.php/shift_manage/shift"> Shift Manage</a></li>
					<?php if ($is_admin) : ?>
				<li><a href="<?php echo base_url() ?>/index.php/home/index">Add Shifts </a> </li>
						<?php else : ?>
						<?php endif; ?>
				<li class="divider-vertical"></li>
				<li> <a href="javascript:%20shift_update('edit') " ><div style="padding-left:100px; font-size:17px;"> <?php echo $currentshift[0]->name ; ?> </div></a></li>
				</ul>
				<div class="btn-group pull-right">
					<?php if ($is_admin) : ?>
					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
						<i class="icon-wrench"></i> admin	<span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a data-toggle="modal" href="#myModal"><i class="icon-user"></i> New User</a></li>
						<li class="divider"></li>
						<li><a href="<?php echo base_url() ?>/index.php/login/logout_user"><i class="icon-share"></i> Logout</a></li>
					</ul>
					<?php else : ?>
						<a class="btn" href="<?php echo base_url() ?>/index.php/login/logout_user"><i class="icon-share"></i> Logout</a>
					<?php endif; ?>
				</div>
		</div>
		<!--/.container-fluid -->
	</div>
	<!--/.navbar-inner -->
</div>
<!--/.navbar -->
