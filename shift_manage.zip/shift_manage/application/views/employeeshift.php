

  <script src="<?php echo base_url();?>assets/js/calander_js/jquery-1.9.1.min.js"></script>
<div id="body">




<div id="shift" class="shift" style="font-color:red;">
	<?php foreach($requestshift as $me){
      if($me->up_shift != 0){
       echo $me->firstName.' '.$me->lastName .' Sent request to change shift to '.$me->name ;
		  }

		 } ?>
</div>

		<h4><?php if(isset($summary) && $summary != "") echo $summary; ?></h4>
		<div id="shift" class="shift">
		<table class='table'>
			<tr>

				<td><strong>Email </strong></td>
				<td><strong>Employee Name </strong></td>
				<td><strong>Shift Name </strong></td>
				<td><strong>Update shift</strong></td>
				<td><strong>Action</strong></td>
			</tr>
			<?php foreach($userdata as $m){ ?>
				<tr>

					<td> <?php echo $m->email; ?> </td>
					<td> <?php echo $m->firstName.' '.$m->lastName; ?> </td>
					<td> <?php echo $m->name; ?> </td>

					<td>

					 <select  id="up_shift_<?php echo $m->id; ?>" name="up_shift_<?php echo $m->id; ?>" >
						  <option>--select--</option>
						 	<?php foreach($allshift as $a){ ?>
             <option value="<?php echo $a['id']; ?>"> <?php echo $a['name']; ?> </option>
             <?php } ?>
					 </select>

					</td>
					<td>
						 <a href="javascript:%20edit_shift('<?php echo $m->id; ?>')" >Edit</a>
			    </td>
				</tr>
			<?php } ?>
		</table>
	</div>

<script>

function edit_shift(id)
{

	var shiftid = document.getElementById('up_shift_'+id).value ;

	$(function ()
	{
	$.ajax({ url:'editshift',
	         data:"id="+id+"&shiftid="+shiftid,
	         dataType:'json',
	         type:"post",
	        success: function(result){
	    }});
    })
		window.location.reload(true);
}


</script>
