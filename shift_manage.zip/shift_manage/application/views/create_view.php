<?php //$this->load->view('mainnev');  ?>

<div id="shift">
		<h4><?php if(isset($summary) && $summary != "") echo $summary; ?></h4>
		<form method="POST" action="<?php echo base_url() ?>index.php/create/input/" style="text-align:center;">
			<h4>Create Shift</h4> <br/><br/>
			Name:<input type="text" name="name" size="50"/><br/>
			Start Time:<input type="text" name="starttime" size="50"/><br/>
			End Time: <input type="text" size="50" name="endtime"><br/>
			<input type="submit" value="Submit" />
		</form>
	</div>
