-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 15, 2017 at 02:23 PM
-- Server version: 5.6.35
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jsramco_shift`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE `calendar` (
  `id` int(11) NOT NULL,
  `event` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `datetime` date NOT NULL,
  `section` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`id`, `event`, `description`, `datetime`, `section`, `userId`, `shift_id`) VALUES
(264, 'Morning Shift', 'Morning Shift', '2017-06-12', 1, 1, 64),
(265, 'Morning Shift', 'Morning Shift', '2017-06-13', 1, 1, 64),
(267, 'Morning Shift', 'Morning Shift', '2017-06-15', 1, 1, 64),
(269, 'Night Shift', 'Night Shift', '2017-06-24', 1, 1, 66),
(270, 'Evening Shift', 'Evening Shift', '2017-06-16', 1, 1, 65),
(271, 'Evening Shift', 'Evening Shift', '2017-06-17', 1, 1, 65),
(272, 'Morning Shift', 'Morning Shift', '2017-06-15', 1, 2, 64),
(273, 'Morning Shift', 'Morning Shift', '2017-06-16', 1, 2, 64),
(274, 'Morning Shift', 'Morning Shift', '2017-06-17', 1, 2, 64),
(275, 'Morning Shift', 'Morning Shift', '2017-06-18', 1, 2, 64);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('31b104a183130f6de695ee2c556120ae', '117.224.3.188', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/51.0.2704.79 Chrome/51.0.2704.79 ', 1497530876, 'a:9:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:4:\"name\";s:15:\"Admin Schmadmin\";s:5:\"email\";s:17:\"admin@example.com\";s:6:\"avatar\";s:15:\"assassin_avatar\";s:7:\"tagline\";s:42:\"They see me mowin...<br/>...my front lawn.\";s:7:\"isAdmin\";s:1:\"1\";s:6:\"teamId\";s:1:\"1\";s:10:\"isLoggedIn\";b:1;}'),
('3b4693e052290c4073639af9e4d1e299', '117.225.75.171', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/51.0.2704.79 Chrome/51.0.2704.79 ', 1497532861, 'a:9:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:4:\"name\";s:15:\"Admin Schmadmin\";s:5:\"email\";s:17:\"admin@example.com\";s:6:\"avatar\";s:15:\"assassin_avatar\";s:7:\"tagline\";s:42:\"They see me mowin...<br/>...my front lawn.\";s:7:\"isAdmin\";s:1:\"1\";s:6:\"teamId\";s:1:\"1\";s:10:\"isLoggedIn\";b:1;}'),
('4e94536b078f7fecc0768acb3c82db71', '76.76.165.148', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 1497532854, 'a:9:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:4:\"name\";s:15:\"Admin Schmadmin\";s:5:\"email\";s:17:\"admin@example.com\";s:6:\"avatar\";s:15:\"assassin_avatar\";s:7:\"tagline\";s:42:\"They see me mowin...<br/>...my front lawn.\";s:7:\"isAdmin\";s:1:\"1\";s:6:\"teamId\";s:1:\"1\";s:10:\"isLoggedIn\";b:1;}'),
('992143f8148393052a1689d6be5377de', '117.225.239.14', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko/20100101 Firefox/49.0', 1497532445, 'a:9:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:4:\"name\";s:15:\"Admin Schmadmin\";s:5:\"email\";s:17:\"admin@example.com\";s:6:\"avatar\";s:15:\"assassin_avatar\";s:7:\"tagline\";s:42:\"They see me mowin...<br/>...my front lawn.\";s:7:\"isAdmin\";s:1:\"1\";s:6:\"teamId\";s:1:\"1\";s:10:\"isLoggedIn\";b:1;}'),
('ad7f9ee2250bf37d8c4ed3650b604a61', '40.78.146.128', 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', 1497532871, ''),
('c440266ba4e034fc9f74d246a1bf0f17', '76.76.165.148', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/', 1497532190, 'a:9:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:4:\"name\";s:15:\"Admin Schmadmin\";s:5:\"email\";s:17:\"admin@example.com\";s:6:\"avatar\";s:15:\"assassin_avatar\";s:7:\"tagline\";s:42:\"They see me mowin...<br/>...my front lawn.\";s:7:\"isAdmin\";s:1:\"1\";s:6:\"teamId\";s:1:\"1\";s:10:\"isLoggedIn\";b:1;}'),
('fb57a31b523ff7f9f374b01fc835c248', '13.76.241.210', 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', 1497532894, '');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `id` int(11) NOT NULL,
  `section` varchar(25) NOT NULL,
  `starttime` time(6) NOT NULL,
  `endtime` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`id`, `section`, `starttime`, `endtime`) VALUES
(1, 'Title', '00:00:00.000000', '00:00:00.000000'),
(2, '1:00 -- 2:00', '00:00:00.000000', '02:00:00.000000'),
(3, '2:00 -- 3:00', '02:00:00.000000', '03:00:00.000000'),
(4, '3:00 -- 4:00', '03:00:00.000000', '04:00:00.000000'),
(5, '4:00 -- 5:00', '04:00:00.000000', '05:00:00.000000'),
(6, '5:00 -- 6:00', '05:00:00.000000', '06:00:00.000000'),
(7, '6:00 -- 7:00', '06:00:00.000000', '07:00:00.000000'),
(8, '7:00 -- 8:00', '07:00:00.000000', '08:00:00.000000'),
(9, '8:00 - 9:00', '08:00:00.000000', '09:00:00.000000'),
(10, '9:00 -- 10:00', '09:00:00.000000', '10:00:00.000000'),
(11, '10:00 --  11:00', '10:00:00.000000', '11:00:00.000000'),
(12, '11:00 --12:00', '11:00:00.000000', '12:00:00.000000'),
(13, '12:00 -- 13:00', '12:00:00.000000', '13:00:00.000000'),
(14, '13:00-- 14:00', '13:00:00.000000', '14:00:00.000000'),
(15, '14:00 -- 15:00', '14:00:00.000000', '15:00:00.000000'),
(16, '15:00 -- 16:00', '15:00:00.000000', '16:00:00.000000'),
(17, '16:00 -- 17:00', '16:00:00.000000', '17:00:00.000000'),
(18, '17:00 -- 18:00', '17:00:00.000000', '18:00:00.000000'),
(19, '18:00 --19:00', '18:00:00.000000', '19:00:00.000000'),
(20, '19:00 -- 20:00', '19:00:00.000000', '20:00:00.000000'),
(21, '20:00 -- 21:00', '20:00:00.000000', '21:00:00.000000'),
(22, '21:00 -- 22:00', '21:00:00.000000', '22:00:00.000000'),
(23, '22:00 -- 23:00', '22:00:00.000000', '23:00:00.000000'),
(24, '23:00 -- 24:00', '23:00:00.000000', '23:59:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `shift`
--

CREATE TABLE `shift` (
  `id` int(255) NOT NULL COMMENT 'id auto increment',
  `name` varchar(255) NOT NULL,
  `starttime` time(6) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endtime` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shift`
--

INSERT INTO `shift` (`id`, `name`, `starttime`, `date`, `endtime`) VALUES
(64, 'Morning Shift', '08:00:00.000000', '2017-06-12 18:30:00', '14:00:00.000000'),
(65, 'Evening Shift', '14:00:00.000000', '2017-06-14 18:30:00', '20:00:00.000000'),
(66, 'Night Shift', '19:18:00.000000', '2017-06-14 18:30:00', '23:18:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `firstName` varchar(45) DEFAULT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `tagline` varchar(255) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT NULL,
  `shift_id` int(11) NOT NULL,
  `up_shift` int(11) NOT NULL,
  `up_date` date NOT NULL,
  `all_shift` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `firstName`, `lastName`, `avatar`, `tagline`, `teamId`, `isAdmin`, `shift_id`, `up_shift`, `up_date`, `all_shift`) VALUES
(1, 'admin@example.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Admin', 'Schmadmin', 'assassin_avatar', 'They see me mowin...<br/>...my front lawn.', 1, 1, 64, 65, '2017-06-18', ''),
(2, 'bb@example.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'bb', 'example', NULL, NULL, NULL, 0, 64, 0, '2017-06-16', ''),
(3, 'jj@example.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'jj', 'Last', NULL, NULL, NULL, 0, 62, 0, '0000-00-00', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `shift`
--
ALTER TABLE `shift`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calendar`
--
ALTER TABLE `calendar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=276;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `shift`
--
ALTER TABLE `shift`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'id auto increment', AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
